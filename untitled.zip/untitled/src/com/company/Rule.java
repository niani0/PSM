package com.company;

public class Rule {
    char axiom;
    String rule;

    public Rule(char axiom, String rule) {
        this.axiom = axiom;
        this.rule = rule;
    }
}
